module.exports.workspaceActions = require('./src/WorkspaceActions');
module.exports.requestActions = [require('./src/RequestAction')];
module.exports.requestHooks = [require('./src/RequestHook')];
module.exports.responseHooks = [require('./src/ResponseHook')];
